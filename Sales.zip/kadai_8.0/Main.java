/**
 * 売上入力画面と、売上情報を記録する画面を表示するクラス。
 * 
 * @author 大岡　勇輝
 * コードレビュー：井上　大誠
 */
public class Main extends Object{

    /**
     * エントリポイント
     * 売り上げ可視化アプリを起動する
     * 
     * @param args 実行時引数。ここでは使用しない。
     */
    public static void main(String[] args) {
        
        SalesVisualize anApplication = new SalesVisualize("SalesVisualize");

        anApplication.perform();

    }

}