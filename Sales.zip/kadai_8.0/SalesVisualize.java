import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import java.awt.BorderLayout;
import java.awt.Container;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.ButtonGroup;


/**
 * 売上可視化アプリのプログラム 
 */

public class SalesVisualize extends JFrame {
    
    /**
     * 売上可視化アプリのプログラムを実行する
     */
    
    
        

    /**
     * ウィンドウを作成する
     */
    SalesVisualize(String name){
        setTitle(name);
        setBounds(100,100,600,400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

    public void perform(){
        //結果入力用パネルを作成する
        JPanel checkpanel = new JPanel();
        checkpanel.setLayout(null);
        
        
        
        
        //クラス選択を実装する
        JLabel className = new JLabel("クラス");
        className.setBounds(30,10,150,50);
        JRadioButton classradio1 = new JRadioButton("1-1");
        classradio1.setBounds(45, 40, 100, 25);
        classradio1.setSelected(true);
        JRadioButton classradio2 = new JRadioButton("1-2");
        classradio2.setBounds(45, 65, 100, 25);

        //金券選択を実装する
        JLabel moneytoken = new JLabel("金券");
        moneytoken.setBounds(30, 70, 150, 50);
        JRadioButton tokenradio1 = new JRadioButton("50円券");
        tokenradio1.setBounds(45,100,100,25);
        tokenradio1.setSelected(true);
        JRadioButton tokenradio2 = new JRadioButton("100円券");
        tokenradio2.setBounds(45,125,100,25);
        
        //選択を記録するボタンを作成する
        JButton CHECK = new JButton("CHECK");
        CHECK.setBounds(45,150,100,25);
        
        
        //結果記録用パネルを作成する
        JPanel LogPanel = new JPanel();

        //選択結果記録用のテキストエリアを作成する
        JTextArea DateLog = new JTextArea(15,25);
        DateLog.setEditable(false);

        //記録が増えた際にスクロールバーを表示させる
        JScrollPane scrollPane = new JScrollPane(DateLog);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setBounds(10,10,150,100);
        
        //時間を文字列にして保持する
        JLabel DateLabel = new JLabel();
        TimerTask aTask = new TimerTask(){
            public void run(){
                Date currentDate = new Date();
                DateLabel.setText(currentDate.toString());
            }
        };
        Timer aTimer = new Timer();
        aTimer.scheduleAtFixedRate(aTask, 0, 1000);

        
        
        
        //CHECKボタンの動作を追加する
        CHECK.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent anEvent) {
                StringBuilder TorF = new StringBuilder();
                if (tokenradio1.isSelected()) {
                    TorF.append(DateLabel.getText() + "[50  Selected]" + "\n");
                    //ラジオボタンの入力結果を送信予定
                    //SendDate.doGet();          
                    
                } else if(tokenradio2.isSelected()) {
                    TorF.append(DateLabel.getText() + "[100 Selected]" + "\n");
                    //SendDate.doGet();
                } 
                
                DateLog.setEditable(true);
                DateLog.append(TorF.toString());
                DateLog.setEditable(false);
            }
        });

        
        //ラジオボタンのtrue状態をどちらか一方だけにもたせる
        ButtonGroup ScanButton = new ButtonGroup();
        ScanButton.add(tokenradio1);
        ScanButton.add(tokenradio2);
        ButtonGroup classButton = new ButtonGroup();
        classButton.add(classradio1);
        classButton.add(classradio2);


        checkpanel.add(className);
        checkpanel.add(classradio1);
        checkpanel.add(classradio2);
        checkpanel.add(moneytoken);
        checkpanel.add(tokenradio1);
        checkpanel.add(tokenradio2);
        checkpanel.add(CHECK);
        LogPanel.add(scrollPane);
    
        
        Container ContentPane = getContentPane();
        ContentPane.add(LogPanel,BorderLayout.EAST);
        ContentPane.add(checkpanel,BorderLayout.CENTER);
        setVisible(true);
    }
}
